# MedGuard repair notes

## Fixed / improved
- Fixed demo-case loading so it stages the source medicines before deleting the destination list; loading the same case no longer empties the patient's medicines.
- Required authentication for demo-case listing.
- Added request body size/type checks and consistent client-facing error messages.
- Added login throttling, session token format validation, expired-session cleanup during login, same-origin checks for browser mutations, `HttpOnly`/`SameSite` cookies and production `Secure` cookies.
- Added strict profile validation and duplicate-medicine conflict responses instead of silently swallowing database errors.
- Added ownership/role checks and safer not-found responses around report acknowledgement, report sharing and patient records.
- Added report-share revocation endpoint and stronger random share tokens.
- Hardened password verification against malformed hashes while retaining compatibility with the original demo hash format.
- Improved engine ingredient normalization, malformed profile handling, risk bounds and explicit disclosure of screening limitations.
- Added SQLite busy timeout and indexes for common lookups.
- Fixed API request option/header merging, toast timer handling, stale medicine-search responses and several unhandled frontend action errors.
- Removed the bundled SQLite database, WAL and SHM files from the release archive so local user/session data is not distributed.
- Replaced CDN-loaded OCR with the locally installed Tesseract.js browser library; prescription and report image recognition now run in-browser.
- Removed the OCR-specific `/api/ocr/*` routes and moved prescription line-to-catalogue matching into the frontend; the backend only supplies the medicine catalogue and persists selected medicines/reports.
- Added local static serving for Tesseract.js worker/core assets and updated setup/security documentation.

## Validation performed
- JavaScript syntax checks for all server and browser JavaScript files.
- `npm test`: 8 automated tests passed.
- Integration smoke test passed for static app delivery, login, authorization, self-demo loading regression, OCR authentication, review creation, share creation and share revocation.

## Remaining limitations
- The medication catalogue and interaction rules remain a small demonstration dataset, not a clinically complete reference.
- No dose-aware analysis, allergy checks, laboratory integration, validated risk model, formal audit logging, or independent penetration/clinical validation is included. OCR is English-only and its language data may need an initial download.
- This release is not suitable for real patient data or clinical decision-making.


## Doctor verification visibility
- Patient report lists display the verifying doctor and verification timestamp.
- Pending reports are labeled as awaiting doctor verification; correction requests and doctor notes are visible to patients.
- Doctor report lists show the clinician who recorded the decision.
