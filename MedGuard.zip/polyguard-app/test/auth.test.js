const test = require('node:test');
const assert = require('node:assert/strict');
const { hashPassword, verifyPassword, token } = require('../src/auth');

test('password hashes verify and do not reveal plaintext', async () => {
  const password = 'demo-password-123';
  const hash = await hashPassword(password);
  assert.notEqual(hash, password);
  assert.equal(await verifyPassword(password, hash), true);
  assert.equal(await verifyPassword('incorrect', hash), false);
});

test('malformed hashes fail closed', async () => {
  assert.equal(await verifyPassword('anything', ''), false);
  assert.equal(await verifyPassword('anything', 'bad-hash'), false);
  assert.equal(await verifyPassword('anything', null), false);
});

test('legacy salt:hex hashes remain verifiable', async () => {
  const crypto = require('node:crypto');
  const { promisify } = require('node:util');
  const scrypt = promisify(crypto.scrypt);
  const salt = crypto.randomBytes(16).toString('hex');
  const password = 'legacy-password';
  const key = await scrypt(password, salt, 64);
  assert.equal(await verifyPassword(password, `${salt}:${key.toString('hex')}`), true);
});

test('session tokens have 256 bits of entropy in hex form', () => {
  assert.match(token(), /^[a-f0-9]{64}$/);
});

test('password length is validated', async () => {
  await assert.rejects(() => hashPassword('short'), /between 8 and 1024/);
});
