const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'medguard-test-'));
process.env.MEDGUARD_DB_PATH = path.join(tempDir, 'test.db');
const db = require('../src/db');
const { analyze, normalizeIngredient } = require('../src/engine');

test('ingredient normalization is consistent', () => {
  assert.equal(normalizeIngredient('  Ibuprofen  '), 'ibuprofen');
  assert.equal(normalizeIngredient('PARACETAMOL'), 'paracetamol');
});

test('empty patient list returns bounded zero risk and honest coverage', () => {
  const user = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES('Test','test@example.test','x','patient')").run();
  const patientId = Number(user.lastInsertRowid);
  db.prepare('INSERT INTO profiles(patient_id,age,sex,conditions) VALUES(?,?,?,?)').run(patientId, 30, 'Not specified', '[]');
  const result = analyze(patientId);
  assert.equal(result.risk, 0);
  assert.deepEqual(result.findings, []);
  assert.ok(result.coverage.unresolved.length > 0);
});

test('malformed profile conditions do not crash analysis', () => {
  const user = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES('Test2','test2@example.test','x','patient')").run();
  const patientId = Number(user.lastInsertRowid);
  db.prepare('INSERT INTO profiles(patient_id,age,sex,conditions) VALUES(?,?,?,?)').run(patientId, 30, 'Not specified', '{bad json');
  assert.doesNotThrow(() => analyze(patientId));
});

test.after(() => { db.close(); fs.rmSync(tempDir, { recursive: true, force: true }); });
