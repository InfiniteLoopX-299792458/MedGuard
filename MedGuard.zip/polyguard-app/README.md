# MedGuard — medication safety demonstration

A lightweight full-stack demonstration with a patient/doctor interface, Node.js HTTP API, SQLite persistence, deterministic interaction screening, prescription-text matching, saved reports and expiring read-only share links.

## Requirements
- Node.js 22.5+ (uses the built-in `node:sqlite` module)

## Run locally
```bash
npm run seed
npm start
```
Open http://127.0.0.1:5173

Demo password for all seeded accounts: `demo1234`

| Role | Email |
|---|---|
| Patient | meera@demo.in |
| Patient | arjun@demo.in |
| Patient | fatima@demo.in |
| Patient | ravi@demo.in |
| Doctor | rao@demo.in |
| Doctor | iyer@demo.in |

## Tests
```bash
npm test
```

## Configuration
- `MEDGUARD_DB_PATH`: optional absolute path for the SQLite database.
- `HOST`: bind address (defaults to `127.0.0.1`).
- `PORT`: HTTP port (defaults to `5173`).
- `NODE_ENV=production`: enables the `Secure` cookie attribute; production must use HTTPS.

## Included
- Patient dashboard: medicines, profile/conditions, review history, review generation, prescription OCR and medical-report uploads.
- Doctor dashboard: linked patients, patient records, review generation, clinician acknowledgement and patient-report verification.
- Deterministic interaction screening using a deliberately small seeded dataset.
- Read-only report sharing with seven-day expiry and revocation.
- Browser-based English OCR for prescription and medical-report images (JPG, PNG, WebP; up to 8 MB).
- Patient medical-report inbox with pending, verified and needs-correction states, plus clinician notes.
- Print-friendly reports and responsive interface.

## Safety and limitations
**This is a demonstration application, not a clinically validated medication decision-support system.** Its catalogue and interaction rules are incomplete. A report with no findings does not establish that a medication list is safe. It does not assess dosage appropriateness, timing, allergies, laboratory results, contraindications beyond its small rule set, or many known interactions. Never use it to start, stop, or change treatment. All findings require independent review by a licensed clinician or pharmacist. Do not enter real patient information into this demo.

The application includes basic request validation, session expiry, login throttling, same-origin checks for browser mutations, secure cookie configuration for production, and role/ownership checks. These controls are not a substitute for a professional security assessment, CSRF design review, audit logging, privacy review, dependency monitoring, penetration testing or clinical governance. Do not expose this demo directly to the public internet.

The OCR feature uses the locally installed Tesseract.js browser library (no external OCR API or OCR CDN script). The first OCR run may still need internet access to download the English language data unless it is cached by the browser. OCR is English-only in this build. Patients should review extracted text before submission. The app stores the extracted text and filename, not the original image; clinicians must compare the OCR text with the original report supplied by the patient before marking it verified. Verification records an administrative clinician review, not proof of authenticity or a clinical diagnosis. The UI loads DM Sans and Manrope from Google Fonts when internet is available and falls back to system fonts offline.

## Database
The database is created locally by `npm run seed`. Database files, session records and local user data are intentionally not distributed in the source archive.
