const db = require('./db');

const SEVERITY_POINTS = Object.freeze({ critical: 55, high: 30, moderate: 15, low: 5 });
const NSAIDS = new Set(['ibuprofen', 'diclofenac', 'naproxen']);
function normalizeIngredient(value) { return String(value || '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase(); }
function safeConditions(raw) { try { const value = JSON.parse(raw || '[]'); return Array.isArray(value) ? value : []; } catch { return []; } }
function analyze(patientId) {
  const profile = db.prepare('SELECT * FROM profiles WHERE patient_id=?').get(patientId) || { age: 30, conditions: '[]' };
  const meds = db.prepare(`SELECT pm.id, m.brand, m.ingredients, m.category, pm.prescriber FROM patient_medicines pm JOIN medicines m ON m.id=pm.medicine_id WHERE pm.patient_id=? ORDER BY m.brand`).all(patientId);
  const ingredientMap = new Map();
  for (const med of meds) for (const raw of String(med.ingredients || '').split(',')) {
    const key = normalizeIngredient(raw);
    if (key && !ingredientMap.has(key)) ingredientMap.set(key, raw.trim());
  }
  const ingredients = [...ingredientMap.keys()];
  const findings = [], seen = new Set();
  const interactionQuery = db.prepare('SELECT * FROM interactions WHERE (lower(trim(a))=? AND lower(trim(b))=?) OR (lower(trim(a))=? AND lower(trim(b))=?) LIMIT 1');
  for (let i = 0; i < ingredients.length; i++) for (let j = i + 1; j < ingredients.length; j++) {
    const row = interactionQuery.get(ingredients[i], ingredients[j], ingredients[j], ingredients[i]);
    if (!row) continue;
    const key = [normalizeIngredient(row.a), normalizeIngredient(row.b)].sort().join('|');
    if (seen.has(key)) continue;
    seen.add(key);
    findings.push({ type: 'interaction', severity: row.severity, title: `${row.a} + ${row.b}`, mechanism: row.mechanism, why: row.why, question: row.question });
  }
  const conditions = safeConditions(profile.conditions);
  if (conditions.includes('Kidney disease') && ingredients.some(x => NSAIDS.has(x))) findings.push({ type: 'condition', severity: 'high', title: 'NSAID with kidney disease', mechanism: 'Potential reduction in renal blood flow', why: 'NSAIDs may worsen kidney function in susceptible people.', question: 'Ask your clinician whether an alternative pain reliever is appropriate.' });
  if (Number(profile.age) >= 65 && ingredients.includes('diazepam')) findings.push({ type: 'geriatric', severity: 'moderate', title: 'Diazepam in adults aged 65+', mechanism: 'Increased sensitivity to sedatives', why: 'May increase confusion and fall risk in older adults.', question: 'Ask whether the dose and duration remain appropriate.' });
  const counts = { critical: 0, high: 0, moderate: 0, low: 0 };
  for (const finding of findings) if (Object.hasOwn(counts, finding.severity)) counts[finding.severity]++;
  const raw = findings.reduce((sum, f) => sum + (SEVERITY_POINTS[f.severity] || 5), 0);
  const risk = Math.max(0, Math.min(100, Math.round(100 * (1 - Math.exp(-raw / 45)))));
  const totalBrands = db.prepare('SELECT COUNT(*) AS n FROM medicines').get().n;
  return { risk, findings, medicines: meds, coverage: { brands: totalBrands, pairsChecked: ingredients.length * (ingredients.length - 1) / 2, unresolved: ['Dose, frequency, duration, allergies, laboratory results and unlisted interactions are not assessed.'], datasetVersion: 'MedGuard demo dataset 1.1' }, counts };
}
module.exports = { analyze, normalizeIngredient };
