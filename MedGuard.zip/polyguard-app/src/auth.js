const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);
const KEY_LENGTH = 64;

async function hashPassword(password) {
  if (typeof password !== 'string' || password.length < 8 || password.length > 1024) {
    throw new TypeError('Password must be between 8 and 1024 characters');
  }
  const salt = crypto.randomBytes(16).toString('hex');
  const key = await scrypt(password, salt, KEY_LENGTH);
  return `scrypt$${salt}$${key.toString('hex')}`;
}

async function verifyPassword(password, stored) {
  if (typeof password !== 'string' || typeof stored !== 'string') return false;
  const parts = stored.includes('$') ? stored.split('$') : stored.split(':');
  // Accept the original salt:hex format as well as the versioned scrypt$salt$hex format.
  const [scheme, salt, hex] = stored.includes('$') ? parts : ['scrypt', parts[0], parts[1]];
  if (scheme !== 'scrypt' || !/^[a-f0-9]{32}$/i.test(salt || '') || !/^[a-f0-9]{128}$/i.test(hex || '')) return false;
  try {
    const key = await scrypt(password, salt, KEY_LENGTH);
    return crypto.timingSafeEqual(key, Buffer.from(hex, 'hex'));
  } catch { return false; }
}

function token() { return crypto.randomBytes(32).toString('hex'); }
module.exports = { hashPassword, verifyPassword, token };
