const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const file = process.env.MEDGUARD_DB_PATH || path.join(__dirname, '../data/medguard.db');
fs.mkdirSync(path.dirname(file), { recursive: true });
const db = new DatabaseSync(file);
db.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
db.exec(fs.readFileSync(path.join(__dirname, '../data/schema.sql'), 'utf8'));
db.exec(`
  CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
  CREATE INDEX IF NOT EXISTS idx_patient_medicines_patient ON patient_medicines(patient_id);
  CREATE INDEX IF NOT EXISTS idx_reviews_patient ON reviews(patient_id, id DESC);
  CREATE INDEX IF NOT EXISTS idx_shares_token_expiry ON shares(token, expires_at, revoked);
  CREATE INDEX IF NOT EXISTS idx_users_doctor ON users(doctor_id, role);
`);
module.exports = db;
