const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const db = require('./db');
const { verifyPassword, token } = require('./auth');
const { analyze } = require('./engine');

const ROOT = path.resolve(__dirname, '../public');
const PORT = Number(process.env.PORT || 5173);
const HOST = process.env.HOST || '127.0.0.1';
const COOKIE_SECURE = process.env.NODE_ENV === 'production' ? '; Secure' : '';
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.wasm': 'application/wasm', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.ico': 'image/x-icon' };
const NODE_MODULES = path.resolve(__dirname, '../node_modules');
const loginAttempts = new Map();

function send(res, status, data, headers = {}) {
  if (res.headersSent) return;
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers });
  res.end(JSON.stringify(data));
}
function body(req) {
  return new Promise((resolve, reject) => {
    let raw = '', settled = false;
    req.on('data', chunk => {
      if (settled) return;
      raw += chunk.toString('utf8');
      if (Buffer.byteLength(raw) > 1024 * 1024) { settled = true; reject(Object.assign(new Error('Request body too large'), { status: 413 })); req.destroy(); }
    });
    req.on('end', () => {
      if (settled) return;
      try { const parsed = raw ? JSON.parse(raw) : {}; if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error(); resolve(parsed); }
      catch { reject(Object.assign(new Error('Invalid JSON body'), { status: 400 })); }
    });
    req.on('error', err => { if (!settled) reject(err); });
  });
}
function cookieValue(req, name) {
  const raw = req.headers.cookie || '';
  const match = raw.match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : null;
}
function user(req) {
  const sid = cookieValue(req, 'sid');
  if (!sid || !/^[a-f0-9]{64}$/i.test(sid)) return null;
  return db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>?').get(sid, Date.now()) || null;
}
function need(req, res, role) {
  const current = user(req);
  if (!current) { send(res, 401, { error: 'Sign in required' }); return null; }
  if (role && current.role !== role) { send(res, 403, { error: 'Not allowed' }); return null; }
  return current;
}
function patientAccess(current, id) {
  const patientId = Number(id);
  if (!Number.isSafeInteger(patientId) || patientId < 1) return false;
  return current.role === 'patient' ? current.id === patientId : db.prepare("SELECT 1 FROM users WHERE id=? AND doctor_id=? AND role='patient'").get(patientId, current.id) != null;
}
function getReport(id) {
  const row = db.prepare('SELECT * FROM reviews WHERE id=?').get(id);
  if (!row) return null;
  try { return { ...row, findings: JSON.parse(row.findings), medicines: JSON.parse(row.medicines), coverage: JSON.parse(row.coverage) }; }
  catch { return null; }
}
function validText(value, max = 120) { return typeof value === 'string' && value.trim().length > 0 && value.trim().length <= max; }
function mutationAllowed(req) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return true;
  if (req.headers['sec-fetch-site'] === 'cross-site') return false;
  const origin = req.headers.origin;
  if (!origin) return true; // Non-browser clients; cookie SameSite=Lax remains enabled.
  try { return new URL(origin).host === (req.headers.host || ''); } catch { return false; }
}
function loginAllowed(req) {
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const old = loginAttempts.get(ip) || { count: 0, until: now + 15 * 60_000 };
  if (now > old.until) { old.count = 0; old.until = now + 15 * 60_000; }
  if (old.count >= 10) { loginAttempts.set(ip, old); return false; }
  old.count++; loginAttempts.set(ip, old); return true;
}
function saveReview(patientId, doctorId = null) {
  const result = analyze(patientId);
  const saved = db.prepare('INSERT INTO reviews(patient_id,doctor_id,risk,findings,medicines,coverage) VALUES(?,?,?,?,?,?)').run(patientId, doctorId, result.risk, JSON.stringify(result.findings), JSON.stringify(result.medicines), JSON.stringify(result.coverage));
  return Number(saved.lastInsertRowid);
}

async function route(req, res) {
  let url;
  try { url = new URL(req.url, `http://${req.headers.host || 'localhost'}`); }
  catch { return send(res, 400, { error: 'Invalid URL' }); }
  const p = url.pathname, method = req.method;
  try {
    if (!mutationAllowed(req)) return send(res, 403, { error: 'Cross-origin request blocked' });
    if (p === '/api/auth/login' && method === 'POST') {
      if (!loginAllowed(req)) return send(res, 429, { error: 'Too many login attempts. Try again later.' });
      const b = await body(req), email = String(b.email || '').trim().toLowerCase(), password = String(b.password || '');
      if (email.length > 254 || password.length > 1024) return send(res, 400, { error: 'Invalid credentials format' });
      const account = db.prepare('SELECT * FROM users WHERE email=?').get(email);
      if (!account || !await verifyPassword(password, account.password_hash)) return send(res, 401, { error: 'Incorrect email or password' });
      const sid = token();
      db.prepare('DELETE FROM sessions WHERE user_id=? AND expires_at<=?').run(account.id, Date.now());
      db.prepare('INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)').run(sid, account.id, Date.now() + 7 * 864e5);
      return send(res, 200, { user: { id: account.id, name: account.name, email: account.email, role: account.role, specialty: account.specialty } }, { 'Set-Cookie': `sid=${sid}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800${COOKIE_SECURE}` });
    }
    if (p === '/api/auth/logout' && method === 'POST') {
      const sid = cookieValue(req, 'sid'); if (sid) db.prepare('DELETE FROM sessions WHERE token=?').run(sid);
      return send(res, 200, { ok: true }, { 'Set-Cookie': `sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${COOKIE_SECURE}` });
    }
    if (p === '/api/auth/me' && method === 'GET') { const current = user(req); return send(res, 200, { user: current ? { id: current.id, name: current.name, email: current.email, role: current.role, specialty: current.specialty } : null }); }
    if (p === '/api/demo' && method === 'GET') {
      if (!need(req, res, 'patient')) return;
      return send(res, 200, { cases: [{ id: 3, name: 'Meera Sharma', label: 'High risk · 8 medicines' }, { id: 4, name: 'Arjun Mehta', label: 'Bleeding stack' }, { id: 5, name: 'Fatima Khan', label: 'Heart failure · triple therapy' }, { id: 6, name: 'Ravi Kumar', label: 'Clean control' }] });
    }
    if (p === '/api/demo/load' && method === 'POST') {
      const current = need(req, res, 'patient'); if (!current) return;
      const b = await body(req), source = Number(b.case_id);
      if (![3, 4, 5, 6].includes(source)) return send(res, 400, { error: 'Unknown demo case' });
      const profile = db.prepare('SELECT age,sex,conditions FROM profiles WHERE patient_id=?').get(source);
      if (!profile) return send(res, 404, { error: 'Demo profile not found' });
      // Stage medicines before deleting: this also works when the user loads their own demo case.
      db.exec('BEGIN IMMEDIATE');
      try {
        db.prepare('DROP TABLE IF EXISTS temp.demo_medicine_stage').run();
        db.prepare('CREATE TEMP TABLE demo_medicine_stage AS SELECT medicine_id,prescriber FROM patient_medicines WHERE patient_id=?').run(source);
        db.prepare('DELETE FROM patient_medicines WHERE patient_id=?').run(current.id);
        db.prepare('INSERT INTO patient_medicines(patient_id,medicine_id,prescriber) SELECT ?,medicine_id,prescriber FROM demo_medicine_stage').run(current.id);
        db.prepare('UPDATE profiles SET age=?,sex=?,conditions=? WHERE patient_id=?').run(profile.age, profile.sex, profile.conditions, current.id);
        db.exec('DROP TABLE demo_medicine_stage'); db.exec('COMMIT');
      } catch (err) { db.exec('ROLLBACK'); throw err; }
      return send(res, 200, { ok: true });
    }
    if (p === '/api/brands' && method === 'GET') {
      const q = (url.searchParams.get('q') || '').trim().slice(0, 80);
      const all = url.searchParams.get('all') === '1';
      const brands = all ? db.prepare('SELECT id,brand,ingredients,category FROM medicines ORDER BY brand').all() : db.prepare('SELECT * FROM medicines WHERE brand LIKE ? ORDER BY brand LIMIT 12').all(`%${q}%`);
      return send(res, 200, { brands });
    }
    if (p === '/api/conditions' && method === 'GET') return send(res, 200, { conditions: ['Hypertension', 'Diabetes', 'Kidney disease', 'Heart failure', 'Asthma', 'Liver disease', 'Peptic ulcer', 'Pregnancy'] });
    if (p === '/api/patient' && method === 'GET') {
      const current = need(req, res, 'patient'); if (!current) return;
      const profile = db.prepare('SELECT * FROM profiles WHERE patient_id=?').get(current.id);
      if (!profile) return send(res, 404, { error: 'Patient profile not found' });
      const medicines = db.prepare('SELECT pm.id,m.brand,m.ingredients,m.category,pm.prescriber FROM patient_medicines pm JOIN medicines m ON m.id=pm.medicine_id WHERE pm.patient_id=? ORDER BY m.brand').all(current.id);
      const latest = analyze(current.id), reviews = db.prepare('SELECT id,created_at,risk FROM reviews WHERE patient_id=? ORDER BY id DESC LIMIT 8').all(current.id);
      return send(res, 200, { user: { id: current.id, name: current.name }, profile: { ...profile, conditions: JSON.parse(profile.conditions || '[]') }, medicines, stats: { medicineCount: medicines.length, findings: latest.findings.length, risk: latest.risk, reviews: reviews.length }, reviews });
    }
    if (p === '/api/patient/profile' && method === 'PUT') {
      const current = need(req, res, 'patient'); if (!current) return;
      const b = await body(req), age = Number(b.age);
      const allowedConditions = new Set(['Hypertension','Diabetes','Kidney disease','Heart failure','Asthma','Liver disease','Peptic ulcer','Pregnancy']);
      if (!Number.isInteger(age) || age < 0 || age > 120) return send(res, 400, { error: 'Age must be an integer from 0 to 120' });
      if (typeof b.sex !== 'string' || b.sex.length > 40 || !Array.isArray(b.conditions) || b.conditions.length > 20 || b.conditions.some(x => typeof x !== 'string' || !allowedConditions.has(x))) return send(res, 400, { error: 'Invalid profile values' });
      db.prepare('UPDATE profiles SET age=?,sex=?,conditions=? WHERE patient_id=?').run(age, b.sex, JSON.stringify([...new Set(b.conditions)]), current.id);
      return send(res, 200, { ok: true });
    }
    if (p === '/api/patient/medicines' && method === 'POST') {
      const current = need(req, res, 'patient'); if (!current) return;
      const b = await body(req), med = db.prepare('SELECT id FROM medicines WHERE id=? OR brand=?').get(Number(b.medicine_id) || -1, String(b.brand || ''));
      if (!med) return send(res, 404, { error: 'Medicine not found' });
      const prescriber = validText(b.prescriber || 'Self reported', 120) ? String(b.prescriber || 'Self reported').trim() : null;
      if (!prescriber) return send(res, 400, { error: 'Prescriber must be 1–120 characters' });
      try { db.prepare('INSERT INTO patient_medicines(patient_id,medicine_id,prescriber) VALUES(?,?,?)').run(current.id, med.id, prescriber); }
      catch (err) { if (String(err.code).startsWith('SQLITE_CONSTRAINT')) return send(res, 409, { error: 'This medicine is already on your list' }); throw err; }
      return send(res, 201, { ok: true });
    }
    let match = p.match(/^\/api\/patient\/medicines\/(\d+)$/);
    if (match && method === 'DELETE') { const current = need(req, res, 'patient'); if (!current) return; db.prepare('DELETE FROM patient_medicines WHERE id=? AND patient_id=?').run(Number(match[1]), current.id); return send(res, 200, { ok: true }); }
    if (p === '/api/patient/analyze' && method === 'POST') { const current = need(req, res, 'patient'); if (!current) return; return send(res, 201, { review_id: saveReview(current.id) }); }
    if (p === '/api/doctor' && method === 'GET') {
      const current = need(req, res, 'doctor'); if (!current) return;
      const patients = db.prepare("SELECT id,name,email FROM users WHERE role='patient' AND doctor_id=?").all(current.id).map(pt => { const a = analyze(pt.id); return { ...pt, risk: a.risk, findings: a.findings.length, medicines: a.medicines.length }; });
      return send(res, 200, { user: { name: current.name, specialty: current.specialty }, stats: { patients: patients.length, medicines: patients.reduce((s, pt) => s + pt.medicines, 0), highRisk: patients.filter(pt => pt.risk >= 60).length }, patients });
    }
    match = p.match(/^\/api\/doctor\/patients\/(\d+)$/);
    if (match && method === 'GET') {
      const current = need(req, res, 'doctor'); if (!current) return; const id = Number(match[1]);
      if (!patientAccess(current, id)) return send(res, 403, { error: 'Patient is not linked to this doctor' });
      const patient = db.prepare('SELECT id,name,email FROM users WHERE id=?').get(id), profile = db.prepare('SELECT * FROM profiles WHERE patient_id=?').get(id);
      if (!patient || !profile) return send(res, 404, { error: 'Patient not found' });
      return send(res, 200, { patient, profile: { ...profile, conditions: JSON.parse(profile.conditions || '[]') }, ...analyze(id), reviews: db.prepare('SELECT id,created_at,risk FROM reviews WHERE patient_id=? ORDER BY id DESC').all(id) });
    }
    match = p.match(/^\/api\/doctor\/patients\/(\d+)\/medicines$/);
    if (match && method === 'POST') {
      const current = need(req, res, 'doctor'); if (!current) return; const id = Number(match[1]);
      if (!patientAccess(current, id)) return send(res, 403, { error: 'Not linked' });
      const b = await body(req), med = db.prepare('SELECT id FROM medicines WHERE id=? OR brand=?').get(Number(b.medicine_id) || -1, String(b.brand || ''));
      if (!med) return send(res, 404, { error: 'Medicine not found' });
      try { db.prepare('INSERT INTO patient_medicines(patient_id,medicine_id,prescriber) VALUES(?,?,?)').run(id, med.id, current.name); }
      catch (err) { if (String(err.code).startsWith('SQLITE_CONSTRAINT')) return send(res, 409, { error: 'Medicine is already on this patient list' }); throw err; }
      return send(res, 201, { ok: true });
    }
    match = p.match(/^\/api\/doctor\/patients\/(\d+)\/analyze$/);
    if (match && method === 'POST') { const current = need(req, res, 'doctor'); if (!current) return; const id = Number(match[1]); if (!patientAccess(current, id)) return send(res, 403, { error: 'Not linked' }); return send(res, 201, { review_id: saveReview(id, current.id) }); }
    if (p === '/api/patient/documents' && method === 'GET') {
      const current = need(req, res, 'patient'); if (!current) return;
      const documents = db.prepare('SELECT d.id,d.filename,d.document_type,d.extracted_text,d.status,d.verification_note,d.uploaded_at,d.verified_at,d.verified_by,u.name AS verified_by_name FROM patient_documents d LEFT JOIN users u ON u.id=d.verified_by WHERE d.patient_id=? ORDER BY d.id DESC').all(current.id);
      return send(res, 200, { documents });
    }
    if (p === '/api/patient/documents' && method === 'POST') {
      const current = need(req, res, 'patient'); if (!current) return;
      const b = await body(req);
      if (!validText(b.filename, 180) || !validText(b.extracted_text, 10000)) return send(res, 400, { error: 'A filename and OCR text (up to 10,000 characters) are required' });
      const type = validText(b.document_type, 60) ? b.document_type.trim() : 'Medical report';
      const result = db.prepare('INSERT INTO patient_documents(patient_id,filename,document_type,extracted_text) VALUES(?,?,?,?)').run(current.id, b.filename.trim(), type, b.extracted_text.trim());
      return send(res, 201, { id: Number(result.lastInsertRowid), status: 'pending' });
    }
    match = p.match(/^\/api\/doctor\/patients\/(\d+)\/documents$/);
    if (match && method === 'GET') {
      const current = need(req, res, 'doctor'); if (!current) return; const id = Number(match[1]);
      if (!patientAccess(current, id)) return send(res, 403, { error: 'Patient is not linked to this doctor' });
      const documents = db.prepare('SELECT d.id,d.filename,d.document_type,d.extracted_text,d.status,d.verification_note,d.uploaded_at,d.verified_at,d.verified_by,u.name AS verified_by_name FROM patient_documents d LEFT JOIN users u ON u.id=d.verified_by WHERE d.patient_id=? ORDER BY d.id DESC').all(id);
      return send(res, 200, { documents });
    }
    match = p.match(/^\/api\/doctor\/documents\/(\d+)\/verify$/);
    if (match && method === 'POST') {
      const current = need(req, res, 'doctor'); if (!current) return;
      const b = await body(req), doc = db.prepare('SELECT * FROM patient_documents WHERE id=?').get(Number(match[1]));
      if (!doc || !patientAccess(current, doc.patient_id)) return send(res, 404, { error: 'Patient document not found or not accessible' });
      if (!['verified','needs_correction'].includes(b.status)) return send(res, 400, { error: 'Choose verified or needs_correction' });
      const note = typeof b.note === 'string' ? b.note.trim().slice(0, 1000) : '';
      db.prepare('UPDATE patient_documents SET status=?,verification_note=?,verified_by=?,verified_at=CURRENT_TIMESTAMP WHERE id=?').run(b.status, note, current.id, doc.id);
      return send(res, 200, { ok: true });
    }
    if (p === '/api/reviews' && method === 'GET') {
      const current = need(req, res); if (!current) return;
      const rows = current.role === 'patient' ? db.prepare('SELECT id,created_at,risk FROM reviews WHERE patient_id=? ORDER BY id DESC').all(current.id) : db.prepare('SELECT r.id,r.created_at,r.risk,u.name patient_name FROM reviews r JOIN users u ON u.id=r.patient_id WHERE u.doctor_id=? ORDER BY r.id DESC').all(current.id);
      return send(res, 200, { reviews: rows });
    }
    match = p.match(/^\/api\/reviews\/(\d+)$/);
    if (match && method === 'GET') { const current = need(req, res); if (!current) return; const r = getReport(Number(match[1])); if (!r) return send(res, 404, { error: 'Report not found' }); if (!patientAccess(current, r.patient_id)) return send(res, 403, { error: 'Not allowed' }); return send(res, 200, { report: r }); }
    match = p.match(/^\/api\/reviews\/(\d+)\/ack$/);
    if (match && method === 'POST') { const current = need(req, res, 'doctor'); if (!current) return; const r = getReport(Number(match[1])); if (!r || !patientAccess(current, r.patient_id)) return send(res, 404, { error: 'Report not found or not accessible' }); db.prepare('UPDATE reviews SET acknowledged_by=? WHERE id=?').run(current.id, r.id); return send(res, 200, { ok: true }); }
    match = p.match(/^\/api\/reviews\/(\d+)\/share$/);
    if (match && method === 'POST') {
      const current = need(req, res, 'patient'); if (!current) return; const r = getReport(Number(match[1])); if (!r || r.patient_id !== current.id) return send(res, 404, { error: 'Report not found' });
      let share = db.prepare('SELECT * FROM shares WHERE review_id=? AND revoked=0 AND expires_at>?').get(r.id, Date.now());
      if (!share) { const t = crypto.randomBytes(32).toString('hex'); db.prepare('INSERT INTO shares(review_id,token,expires_at) VALUES(?,?,?)').run(r.id, t, Date.now() + 7 * 864e5); share = db.prepare('SELECT * FROM shares WHERE token=?').get(t); }
      return send(res, 200, { url: `${url.origin}/#/shared/${share.token}`, expires_at: share.expires_at, views: share.views });
    }
    match = p.match(/^\/api\/reviews\/(\d+)\/share\/revoke$/);
    if (match && method === 'POST') { const current = need(req, res, 'patient'); if (!current) return; const r = getReport(Number(match[1])); if (!r || r.patient_id !== current.id) return send(res, 404, { error: 'Report not found' }); db.prepare('UPDATE shares SET revoked=1 WHERE review_id=?').run(r.id); return send(res, 200, { ok: true }); }
    if (p.startsWith('/api/shared/') && method === 'GET') {
      const shareToken = p.slice('/api/shared/'.length);
      if (!/^[a-f0-9]{64}$/i.test(shareToken)) return send(res, 404, { error: 'Share link not found' });
      const share = db.prepare('SELECT * FROM shares WHERE token=? AND revoked=0 AND expires_at>?').get(shareToken, Date.now());
      if (!share) return send(res, 404, { error: 'Share link expired or revoked' });
      const r = getReport(share.review_id); if (!r) return send(res, 404, { error: 'Shared report unavailable' });
      db.prepare('UPDATE shares SET views=views+1 WHERE id=?').run(share.id);
      return send(res, 200, { report: { risk: r.risk, findings: r.findings, medicines: r.medicines, coverage: r.coverage, created_at: r.created_at } });
    }
    if (p.startsWith('/api/')) return send(res, 404, { error: 'API route not found' });
    let filePath;
    if (p.startsWith('/vendor/tesseract/')) filePath = path.join(NODE_MODULES, 'tesseract.js', 'dist', path.basename(p));
    else if (p.startsWith('/vendor/tesseract-core/')) filePath = path.join(NODE_MODULES, 'tesseract.js-core', path.basename(p));
    else { try { filePath = path.resolve(ROOT, `.${decodeURIComponent(p === '/' ? '/index.html' : p)}`); } catch { return send(res, 400, { error: 'Invalid path' }); } }
    const isVendorAsset = p.startsWith('/vendor/tesseract/') || p.startsWith('/vendor/tesseract-core/');
    if (isVendorAsset) {
      const allowedRoot = p.startsWith('/vendor/tesseract/') ? path.join(NODE_MODULES, 'tesseract.js', 'dist') : path.join(NODE_MODULES, 'tesseract.js-core');
      if (!filePath.startsWith(allowedRoot + path.sep)) return send(res, 403, { error: 'Forbidden' });
      if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) return send(res, 404, { error: 'OCR asset not installed. Run npm install.' });
    } else {
      if (filePath !== ROOT && !filePath.startsWith(ROOT + path.sep)) return send(res, 403, { error: 'Forbidden' });
      if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) filePath = path.join(ROOT, 'index.html');
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': (path.extname(filePath) === '.html' || path.extname(filePath) === '.js' || path.extname(filePath) === '.wasm') ? 'no-cache' : 'public, max-age=3600' });
    fs.createReadStream(filePath).on('error', () => { if (!res.headersSent) send(res, 500, { error: 'Unable to read asset' }); else res.destroy(); }).pipe(res);
  } catch (err) {
    console.error('Request error:', err);
    send(res, err.status || 500, { error: err.status ? err.message : 'Internal server error' });
  }
}

const server = http.createServer(route);
server.listen(PORT, HOST, () => console.log(`MedGuard running at http://${HOST}:${PORT}`));
function shutdown() { try { db.close(); } finally { server.close(() => process.exit(0)); } }
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
