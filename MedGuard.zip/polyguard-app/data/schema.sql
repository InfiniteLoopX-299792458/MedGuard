PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('patient','doctor')), specialty TEXT, doctor_id INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS medicines(id INTEGER PRIMARY KEY, brand TEXT UNIQUE NOT NULL, ingredients TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'Other');
CREATE TABLE IF NOT EXISTS interactions(id INTEGER PRIMARY KEY, a TEXT NOT NULL, b TEXT NOT NULL, severity TEXT NOT NULL, mechanism TEXT NOT NULL, why TEXT NOT NULL, question TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS patient_medicines(id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES users(id), medicine_id INTEGER NOT NULL REFERENCES medicines(id), prescriber TEXT NOT NULL DEFAULT 'Self reported', created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(patient_id,medicine_id));
CREATE TABLE IF NOT EXISTS profiles(patient_id INTEGER PRIMARY KEY REFERENCES users(id), age INTEGER DEFAULT 30, sex TEXT DEFAULT 'Not specified', conditions TEXT DEFAULT '[]');
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES users(id), doctor_id INTEGER REFERENCES users(id), created_at TEXT DEFAULT CURRENT_TIMESTAMP, risk INTEGER NOT NULL, findings TEXT NOT NULL, medicines TEXT NOT NULL, coverage TEXT NOT NULL, acknowledged_by INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS shares(id INTEGER PRIMARY KEY, review_id INTEGER NOT NULL REFERENCES reviews(id), token TEXT UNIQUE NOT NULL, expires_at INTEGER NOT NULL, views INTEGER DEFAULT 0, revoked INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS patient_documents(id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES users(id), filename TEXT NOT NULL, document_type TEXT NOT NULL DEFAULT 'Medical report', extracted_text TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','verified','needs_correction')), verification_note TEXT, uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP, verified_by INTEGER REFERENCES users(id), verified_at TEXT);
CREATE INDEX IF NOT EXISTS idx_patient_documents_patient ON patient_documents(patient_id, id DESC);
